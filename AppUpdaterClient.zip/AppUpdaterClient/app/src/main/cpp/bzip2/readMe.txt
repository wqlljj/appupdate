bzip2包中文件来来自：
http://www.bzip.org/downloads.html

下载解压得到：bzip2-1.0.6
取其中全部 *.h、*.c 文件。